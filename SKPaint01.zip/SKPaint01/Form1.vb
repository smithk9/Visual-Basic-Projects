﻿Public Class Form1
    Dim Draw = False
    Dim mclrselected As Color = Color.Black
    Private Sub ptbPaint_Click(sender As Object, e As EventArgs) Handles ptbPaint.Click

    End Sub

    Private Sub ptbPaint_MouseDown(sender As Object, e As MouseEventArgs) Handles ptbPaint.MouseDown
        Draw = True
    End Sub

    Private Sub ptbPaint_MouseMove(sender As Object, e As MouseEventArgs) Handles ptbPaint.MouseMove
        If Draw = True Then
            Dim intbrushsize As Integer
            intbrushsize = nudBrushSize.Value

            ptbPaint.CreateGraphics.FillEllipse(New SolidBrush(mclrselected), e.X, e.Y, intbrushsize, intbrushsize)
        End If
    End Sub

    Private Sub ptbPaint_MouseUp(sender As Object, e As MouseEventArgs) Handles ptbPaint.MouseUp
        Draw = False
        Dim bshfill As SolidBrush

        bshfill = New System.Drawing.SolidBrush(mclrselected)
    End Sub

    Private Sub btnColor_Click(sender As Object, e As EventArgs) Handles btnColor.Click
        clrDialog.ShowDialog()
        mclrselected = clrDialog.Color
    End Sub
End Class
