﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ptbPaint = New System.Windows.Forms.PictureBox()
        Me.nudBrushSize = New System.Windows.Forms.NumericUpDown()
        Me.clrDialog = New System.Windows.Forms.ColorDialog()
        Me.btnColor = New System.Windows.Forms.Button()
        CType(Me.ptbPaint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudBrushSize, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ptbPaint
        '
        Me.ptbPaint.Location = New System.Drawing.Point(7, 4)
        Me.ptbPaint.Name = "ptbPaint"
        Me.ptbPaint.Size = New System.Drawing.Size(419, 315)
        Me.ptbPaint.TabIndex = 0
        Me.ptbPaint.TabStop = False
        '
        'nudBrushSize
        '
        Me.nudBrushSize.Location = New System.Drawing.Point(12, 333)
        Me.nudBrushSize.Name = "nudBrushSize"
        Me.nudBrushSize.Size = New System.Drawing.Size(60, 20)
        Me.nudBrushSize.TabIndex = 1
        '
        'btnColor
        '
        Me.btnColor.Location = New System.Drawing.Point(106, 328)
        Me.btnColor.Name = "btnColor"
        Me.btnColor.Size = New System.Drawing.Size(77, 26)
        Me.btnColor.TabIndex = 2
        Me.btnColor.Text = "Color"
        Me.btnColor.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(430, 365)
        Me.Controls.Add(Me.btnColor)
        Me.Controls.Add(Me.nudBrushSize)
        Me.Controls.Add(Me.ptbPaint)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.ptbPaint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudBrushSize, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ptbPaint As PictureBox
    Friend WithEvents nudBrushSize As NumericUpDown
    Friend WithEvents clrDialog As ColorDialog
    Friend WithEvents btnColor As Button
End Class
