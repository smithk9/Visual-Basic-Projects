﻿Public Class Form1
    'Smith Kemper
    'McKeown
    'Program 5
    'Calculates Minimum and Maximun of 5 numbers using Functions.

    Private Sub btnSmall_Click(sender As Object, e As EventArgs) Handles btnSmall.Click
        'Declarations
        Dim shoNum1 As Short
        Dim shoNum2 As Short
        Dim shoNum3 As Short
        Dim shoNum4 As Short
        Dim shoNum5 As Short
        Dim sngNum1 As Single
        Dim sngNum2 As Single
        Dim sngNum3 As Single
        Dim sngNum4 As Single
        Dim sngNum5 As Single
        Dim lngNum1 As Long
        Dim lngNum2 As Long
        Dim lngNum3 As Long
        Dim lngNum4 As Long
        Dim lngNum5 As Long
        Dim shoSmallest As Short
        Dim sngSmallest As Single
        Dim lngSmallest As Long

        'input 
        shoNum1 = txtNum1.Text
        shoNum2 = txtNum2.Text
        shoNum3 = txtNum3.Text
        shoNum4 = txtNum4.Text
        shoNum5 = txtNum5.Text

        sngNum1 = txtNum1.Text
        sngNum2 = txtNum2.Text
        sngNum3 = txtNum3.Text
        sngNum4 = txtNum4.Text
        sngNum5 = txtNum5.Text

        lngNum1 = txtNum1.Text
        lngNum2 = txtNum2.Text
        lngNum3 = txtNum3.Text
        lngNum4 = txtNum4.Text
        lngNum5 = txtNum5.Text

        'Processing 

        shoSmallest = FindMin(shoNum1, shoNum2, shoNum3, shoNum4, shoNum5)
        sngSmallest = FindMIn(sngNum1, sngNum2, sngNum3, sngNum4, sngNum5)
        lngSmallest = FindMin(lngNum1, lngNum2, lngNum3, lngNum4, lngNum5)
        'Output
        lblMin.Text = shoSmallest.ToString
        lblMin.Text = sngSmallest.ToString
        lblMin.Text = lngSmallest.ToString





    End Sub
    Private Sub btnLarge_Click(sender As Object, e As EventArgs) Handles btnLarge.Click
        'Declarations 
        Dim shoNum1 As Short
        Dim shoNum2 As Short
        Dim shoNum3 As Short
        Dim shoNum4 As Short
        Dim shoNum5 As Short
        Dim sngNum1 As Single
        Dim sngNum2 As Single
        Dim sngNum3 As Single
        Dim sngNum4 As Single
        Dim sngNum5 As Single
        Dim lngNum1 As Long
        Dim lngNum2 As Long
        Dim lngNum3 As Long
        Dim lngNum4 As Long
        Dim lngNum5 As Long
        Dim shoLargest As Short
        Dim sngLargest As Short
        Dim lngLargest As Short

        'input
        shoNum1 = txtNum1.Text
        shoNum2 = txtNum2.Text
        shoNum3 = txtNum3.Text
        shoNum4 = txtNum4.Text
        shoNum5 = txtNum5.Text

        sngNum1 = txtNum1.Text
        sngNum2 = txtNum2.Text
        sngNum3 = txtNum3.Text
        sngNum4 = txtNum4.Text
        sngNum5 = txtNum5.Text

        lngNum1 = txtNum1.Text
        lngNum2 = txtNum2.Text
        lngNum3 = txtNum3.Text
        lngNum4 = txtNum4.Text
        lngNum5 = txtNum5.Text

        'Processing
        shoLargest = FindMax(shoNum1, shoNum2, shoNum3, shoNum4, shoNum5)
        sngLargest = FindMax(sngNum1, sngNum2, sngNum3, sngNum4, sngNum5)
        lngLargest = FindMax(lngNum1, lngNum2, lngNum3, lngNum4, lngNum5)

        'Output
        lblMax.Text = shoLargest.ToString
        lblMax.Text = sngLargest.ToString
        lblMax.Text = lngLargest.ToString
    End Sub
    Private Function FindMin(ByVal shoNum1 As Short, ByVal shoNum2 As Short, ByVal shoNum3 As Short,
     Optional ByVal shoNum4 As Short = 0, Optional ByVal shoNum5 As Short = 0) As Short

        Dim shoSmallest As Short




        If shoNum1 < shoNum2 Then
            shoSmallest = shoNum1
        Else
            shoSmallest = shoNum2

        End If

        If shoNum3 < shoSmallest Then
            shoSmallest = shoNum3

        End If
        If shoNum4 > 0 Then
            If shoNum4 < shoSmallest Then
                shoSmallest = shoNum4
            End If
        End If
        If shoNum5 > 0 Then
            If shoNum5 < shoSmallest Then
                shoSmallest = shoNum5
            End If
        End If

        Return shoSmallest

    End Function

    Private Function FindMIn(ByVal sngNum1 As Single, ByVal sngNum2 As Single, ByVal sngNum3 As Single,
     Optional ByVal sngNum4 As Single = 0, Optional ByVal sngNum5 As Single = 0) As Single

        Dim sngSmallest As Single


        If sngNum1 < sngNum2 Then
            sngSmallest = sngNum1
        Else
            sngSmallest = sngNum2
        End If
        If sngNum3 < sngSmallest Then
            sngSmallest = sngNum3

        End If
        If sngNum4 > 0 Then
            If sngNum4 < sngSmallest Then
                sngSmallest = sngNum4
            End If
        End If
        If sngNum5 > 0 Then
            If sngNum5 < sngSmallest Then
                sngSmallest = sngNum5
            End If
        End If

        Return sngSmallest

    End Function

    Private Function FindMin(ByVal lngNum1 As Long, ByVal lngNum2 As Long, ByVal lngNum3 As Long,
     Optional ByVal lngNum4 As Long = 0, Optional ByVal lngNum5 As Long = 0) As Long
        Dim lngSmallest As Long

        If lngNum1 < lngNum2 Then
            lngSmallest = lngNum1
        Else
            lngSmallest = lngNum2
        End If
        If lngNum3 < lngSmallest Then
            lngSmallest = lngNum3

        End If
        If lngNum4 > 0 Then
            If lngNum4 < lngSmallest Then
                lngSmallest = lngNum4
            End If
        End If
        If lngNum5 > 0 Then
            If lngNum5 < lngSmallest Then
                lngSmallest = lngNum5
            End If
        End If
        Return lngSmallest

    End Function

    Private Function FindMax(ByVal shoNum1 As Short, ByVal shoNum2 As Short, ByVal shoNum3 As Short,
     Optional ByVal shoNum4 As Short = 0, Optional ByVal shoNum5 As Short = 0) As Short

        Dim shoLargest As Short

        If shoNum1 > shoNum2 Then
            shoLargest = shoNum1
        Else
            shoLargest = shoNum2
        End If
        If shoNum3 > shoLargest Then
            shoLargest = shoNum3

        End If
        If shoNum4 > 0 Then
            If shoNum4 > shoLargest Then
                shoLargest = shoNum4
            End If
        End If
        If shoNum5 > 0 Then
            If shoNum5 > shoLargest Then
                shoLargest = shoNum5
            End If
        End If

        Return shoLargest

    End Function
    Private Function FindMax(ByVal sngNum1 As Single, ByVal sngNum2 As Single, ByVal sngNum3 As Single,
    Optional ByVal sngNum4 As Single = 0, Optional ByVal sngNum5 As Single = 0) As Single

        Dim sngLargest As Single


        If sngNum1 > sngNum2 Then
            sngLargest = sngNum1
        Else
            sngLargest = sngNum2
        End If
        If sngNum3 > sngLargest Then
            sngLargest = sngNum3

        End If
        If sngNum4 > 0 Then
            If sngNum4 > sngLargest Then
                sngLargest = sngNum4
            End If
        End If
        If sngNum5 > 0 Then
            If sngNum5 > sngLargest Then
                sngLargest = sngNum5
            End If
        End If

        Return sngLargest
    End Function
    Private Function FindMax(ByVal lngNum1 As Long, ByVal lngNum2 As Long, ByVal lngNum3 As Long,
     Optional ByVal lngNum4 As Long = 0, Optional ByVal lngNum5 As Long = 0) As Long

        Dim lngLargest As Long



        If lngNum1 > lngNum2 Then
            lngLargest = lngNum1
        Else
            lngLargest = lngNum2
        End If
        If lngNum3 > lngLargest Then
            lngLargest = lngNum3

        End If
        If lngNum4 > 0 Then
            If lngNum4 > lngLargest Then
                lngLargest = lngNum4
            End If
        End If
        If lngNum5 > 0 Then
            If lngNum5 > lngLargest Then
                lngLargest = lngNum5
            End If
        End If
        Return lngLargest

    End Function

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub
End Class
