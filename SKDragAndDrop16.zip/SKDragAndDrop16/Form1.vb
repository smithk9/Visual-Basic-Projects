﻿Public Class Form1
    'Smith Kemper 
    'McKeown
    'Program 16 Drag and Drop

    Dim number As Integer
    Dim number2 As Integer
    Dim Counter As Integer
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click

        Randomize()
        'Generate random number 
        number = Int(Rnd() * 5) + 1
        number2 = Int(Rnd() * 5)

        txtNum1.Text = number
        txtNum2.Text = number2
        'Resets Random number and Counter 
        lblCorrect.ResetText()
        lblAnswer.ResetText()

        Counter = 0

    End Sub

    Private Sub lblAnswer_DragDrop(sender As Object, e As DragEventArgs) Handles lblAnswer.DragDrop

        lblAnswer.Text = e.Data.GetData(DataFormats.Text).ToString
        'Calls Function
        Calculate()
    End Sub

    Private Sub lblAnswer_DragEnter(sender As Object, e As DragEventArgs) Handles lblAnswer.DragEnter
        If e.Data.GetDataPresent(DataFormats.Text) Then
            e.Effect = DragDropEffects.Move
        Else
            e.Effect = DragDropEffects.None
        End If


    End Sub


    Private Sub lblOne_DragDrop(sender As Object, e As DragEventArgs) Handles lblOne.DragDrop
        lblOne.Text = e.Data.GetData(DataFormats.Text).ToString


    End Sub

    Private Sub lblOne_MouseDown(sender As Object, e As MouseEventArgs) Handles lblOne.MouseDown
        lblOne.DoDragDrop(lblOne.Text, DragDropEffects.Move)
    End Sub


    Private Sub lblTwo_DragDrop(sender As Object, e As DragEventArgs) Handles lblTwo.DragDrop
        lblTwo.Text = e.Data.GetData(DataFormats.Text).ToString
    End Sub

    Private Sub lblTwo_MouseDown(sender As Object, e As MouseEventArgs) Handles lblTwo.MouseDown
        lblTwo.DoDragDrop(lblTwo.Text, DragDropEffects.Move)
    End Sub


    Private Sub lblThree_DragDrop(sender As Object, e As DragEventArgs) Handles lblThree.DragDrop
        lblThree.Text = e.Data.GetData(DataFormats.Text).ToString
    End Sub

    Private Sub lblThree_MouseDown(sender As Object, e As MouseEventArgs) Handles lblThree.MouseDown
        lblThree.DoDragDrop(lblThree.Text, DragDropEffects.Move)
    End Sub


    Private Sub lblFour_DragDrop(sender As Object, e As DragEventArgs) Handles lblFour.DragDrop
        lblFour.Text = e.Data.GetData(DataFormats.Text).ToString
    End Sub

    Private Sub lblFour_MouseDown(sender As Object, e As MouseEventArgs) Handles lblFour.MouseDown
        lblFour.DoDragDrop(lblFour.Text, DragDropEffects.Move)
    End Sub


    Private Sub lblFive_MouseDown(sender As Object, e As MouseEventArgs) Handles lblFive.MouseDown
        lblFive.DoDragDrop(lblFive.Text, DragDropEffects.Move)
    End Sub

    Private Sub lblFive_DragDrop(sender As Object, e As DragEventArgs) Handles lblFive.DragDrop
        lblFive.Text = e.Data.GetData(DataFormats.Text).ToString
    End Sub


    Private Sub lblSix_DragDrop(sender As Object, e As DragEventArgs) Handles lblSix.DragDrop
        lblSix.Text = e.Data.GetData(DataFormats.Text).ToString
    End Sub

    Private Sub lblSix_MouseDown(sender As Object, e As MouseEventArgs) Handles lblSix.MouseDown
        lblFive.DoDragDrop(lblSix.Text, DragDropEffects.Move)
    End Sub


    Private Sub lblSeven_MouseDown(sender As Object, e As MouseEventArgs) Handles lblSeven.MouseDown
        lblSeven.DoDragDrop(lblSeven.Text, DragDropEffects.Move)
    End Sub

    Private Sub lblSeven_DragDrop(sender As Object, e As DragEventArgs) Handles lblSeven.DragDrop
        lblSeven.Text = e.Data.GetData(DataFormats.Text).ToString
    End Sub


    Private Sub lblEight_DragDrop(sender As Object, e As DragEventArgs) Handles lblEight.DragDrop
        lblEight.Text = e.Data.GetData(DataFormats.Text).ToString
    End Sub

    Private Sub lblEight_MouseDown(sender As Object, e As MouseEventArgs) Handles lblEight.MouseDown
        lblEight.DoDragDrop(lblEight.Text, DragDropEffects.Move)
    End Sub

    Private Sub lblNine_MouseDown(sender As Object, e As MouseEventArgs) Handles lblNine.MouseDown
        lblNine.DoDragDrop(lblNine.Text, DragDropEffects.Move)
    End Sub

    Private Sub lblNine_DragDrop(sender As Object, e As DragEventArgs) Handles lblNine.DragDrop
        lblNine.Text = e.Data.GetData(DataFormats.Text).ToString
    End Sub

    Private Sub Calculate()
        Dim Answer As Short

        Answer = lblAnswer.Text
        Counter = Counter + 1

        'Reset After 3 tries
        If Counter > 3 Then
            txtNum1.Clear()
            txtNum2.Clear()
            lblAnswer.ResetText()
            lblCorrect.ResetText()
            Counter = 0

        Else
            'Display Correct or Incorrect
            If Answer = number + number2 Then
                lblCorrect.Text = "Correct!"
            Else
                lblCorrect.Text = "InCorrect"
            End If

        End If








    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub
End Class
