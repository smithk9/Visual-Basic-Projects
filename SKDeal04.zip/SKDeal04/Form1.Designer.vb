﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.pic1 = New System.Windows.Forms.PictureBox()
        Me.pic2 = New System.Windows.Forms.PictureBox()
        Me.pic3 = New System.Windows.Forms.PictureBox()
        Me.pic4 = New System.Windows.Forms.PictureBox()
        Me.pic5 = New System.Windows.Forms.PictureBox()
        Me.btnDeal = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.pic6 = New System.Windows.Forms.PictureBox()
        Me.pic7 = New System.Windows.Forms.PictureBox()
        Me.pic8 = New System.Windows.Forms.PictureBox()
        Me.pic9 = New System.Windows.Forms.PictureBox()
        Me.pic10 = New System.Windows.Forms.PictureBox()
        Me.imlDeck = New System.Windows.Forms.ImageList(Me.components)
        Me.btnReset = New System.Windows.Forms.Button()
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic1
        '
        Me.pic1.Location = New System.Drawing.Point(2, 32)
        Me.pic1.Name = "pic1"
        Me.pic1.Size = New System.Drawing.Size(92, 133)
        Me.pic1.TabIndex = 0
        Me.pic1.TabStop = False
        '
        'pic2
        '
        Me.pic2.Location = New System.Drawing.Point(119, 32)
        Me.pic2.Name = "pic2"
        Me.pic2.Size = New System.Drawing.Size(100, 133)
        Me.pic2.TabIndex = 1
        Me.pic2.TabStop = False
        '
        'pic3
        '
        Me.pic3.Location = New System.Drawing.Point(244, 32)
        Me.pic3.Name = "pic3"
        Me.pic3.Size = New System.Drawing.Size(100, 133)
        Me.pic3.TabIndex = 2
        Me.pic3.TabStop = False
        '
        'pic4
        '
        Me.pic4.Location = New System.Drawing.Point(380, 32)
        Me.pic4.Name = "pic4"
        Me.pic4.Size = New System.Drawing.Size(104, 133)
        Me.pic4.TabIndex = 3
        Me.pic4.TabStop = False
        '
        'pic5
        '
        Me.pic5.Location = New System.Drawing.Point(529, 32)
        Me.pic5.Name = "pic5"
        Me.pic5.Size = New System.Drawing.Size(100, 133)
        Me.pic5.TabIndex = 4
        Me.pic5.TabStop = False
        '
        'btnDeal
        '
        Me.btnDeal.Location = New System.Drawing.Point(756, 297)
        Me.btnDeal.Name = "btnDeal"
        Me.btnDeal.Size = New System.Drawing.Size(75, 23)
        Me.btnDeal.TabIndex = 5
        Me.btnDeal.Text = "Deal"
        Me.btnDeal.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(756, 355)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'pic6
        '
        Me.pic6.Location = New System.Drawing.Point(2, 193)
        Me.pic6.Name = "pic6"
        Me.pic6.Size = New System.Drawing.Size(100, 133)
        Me.pic6.TabIndex = 7
        Me.pic6.TabStop = False
        '
        'pic7
        '
        Me.pic7.Location = New System.Drawing.Point(119, 193)
        Me.pic7.Name = "pic7"
        Me.pic7.Size = New System.Drawing.Size(100, 133)
        Me.pic7.TabIndex = 8
        Me.pic7.TabStop = False
        '
        'pic8
        '
        Me.pic8.Location = New System.Drawing.Point(244, 193)
        Me.pic8.Name = "pic8"
        Me.pic8.Size = New System.Drawing.Size(100, 133)
        Me.pic8.TabIndex = 9
        Me.pic8.TabStop = False
        '
        'pic9
        '
        Me.pic9.Location = New System.Drawing.Point(380, 193)
        Me.pic9.Name = "pic9"
        Me.pic9.Size = New System.Drawing.Size(100, 133)
        Me.pic9.TabIndex = 10
        Me.pic9.TabStop = False
        '
        'pic10
        '
        Me.pic10.Location = New System.Drawing.Point(529, 193)
        Me.pic10.Name = "pic10"
        Me.pic10.Size = New System.Drawing.Size(100, 133)
        Me.pic10.TabIndex = 11
        Me.pic10.TabStop = False
        '
        'imlDeck
        '
        Me.imlDeck.ImageStream = CType(resources.GetObject("imlDeck.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlDeck.TransparentColor = System.Drawing.Color.Transparent
        Me.imlDeck.Images.SetKeyName(0, "2C.GIF")
        Me.imlDeck.Images.SetKeyName(1, "2D.GIF")
        Me.imlDeck.Images.SetKeyName(2, "2H.GIF")
        Me.imlDeck.Images.SetKeyName(3, "2S.GIF")
        Me.imlDeck.Images.SetKeyName(4, "3C.GIF")
        Me.imlDeck.Images.SetKeyName(5, "3D.GIF")
        Me.imlDeck.Images.SetKeyName(6, "3H.GIF")
        Me.imlDeck.Images.SetKeyName(7, "3S.GIF")
        Me.imlDeck.Images.SetKeyName(8, "4C.GIF")
        Me.imlDeck.Images.SetKeyName(9, "4D.GIF")
        Me.imlDeck.Images.SetKeyName(10, "4H.GIF")
        Me.imlDeck.Images.SetKeyName(11, "4S.GIF")
        Me.imlDeck.Images.SetKeyName(12, "5C.GIF")
        Me.imlDeck.Images.SetKeyName(13, "5D.GIF")
        Me.imlDeck.Images.SetKeyName(14, "5H.GIF")
        Me.imlDeck.Images.SetKeyName(15, "5S.GIF")
        Me.imlDeck.Images.SetKeyName(16, "6C.GIF")
        Me.imlDeck.Images.SetKeyName(17, "6D.GIF")
        Me.imlDeck.Images.SetKeyName(18, "6H.GIF")
        Me.imlDeck.Images.SetKeyName(19, "6S.GIF")
        Me.imlDeck.Images.SetKeyName(20, "7C.GIF")
        Me.imlDeck.Images.SetKeyName(21, "7D.GIF")
        Me.imlDeck.Images.SetKeyName(22, "7H.GIF")
        Me.imlDeck.Images.SetKeyName(23, "7S.GIF")
        Me.imlDeck.Images.SetKeyName(24, "8C.GIF")
        Me.imlDeck.Images.SetKeyName(25, "8D.GIF")
        Me.imlDeck.Images.SetKeyName(26, "8H.GIF")
        Me.imlDeck.Images.SetKeyName(27, "8S.GIF")
        Me.imlDeck.Images.SetKeyName(28, "9C.GIF")
        Me.imlDeck.Images.SetKeyName(29, "9D.GIF")
        Me.imlDeck.Images.SetKeyName(30, "9H.GIF")
        Me.imlDeck.Images.SetKeyName(31, "9S.GIF")
        Me.imlDeck.Images.SetKeyName(32, "10C.GIF")
        Me.imlDeck.Images.SetKeyName(33, "10D.GIF")
        Me.imlDeck.Images.SetKeyName(34, "10H.GIF")
        Me.imlDeck.Images.SetKeyName(35, "10S.GIF")
        Me.imlDeck.Images.SetKeyName(36, "AC.GIF")
        Me.imlDeck.Images.SetKeyName(37, "AD.GIF")
        Me.imlDeck.Images.SetKeyName(38, "AH.GIF")
        Me.imlDeck.Images.SetKeyName(39, "AS.GIF")
        Me.imlDeck.Images.SetKeyName(40, "JC.GIF")
        Me.imlDeck.Images.SetKeyName(41, "JD.GIF")
        Me.imlDeck.Images.SetKeyName(42, "JH.GIF")
        Me.imlDeck.Images.SetKeyName(43, "JS.GIF")
        Me.imlDeck.Images.SetKeyName(44, "KC.GIF")
        Me.imlDeck.Images.SetKeyName(45, "KD.GIF")
        Me.imlDeck.Images.SetKeyName(46, "KH.GIF")
        Me.imlDeck.Images.SetKeyName(47, "KS.GIF")
        Me.imlDeck.Images.SetKeyName(48, "QC.GIF")
        Me.imlDeck.Images.SetKeyName(49, "QD.GIF")
        Me.imlDeck.Images.SetKeyName(50, "QH.GIF")
        Me.imlDeck.Images.SetKeyName(51, "QS.GIF")
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(756, 326)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 12
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(865, 408)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.pic10)
        Me.Controls.Add(Me.pic9)
        Me.Controls.Add(Me.pic8)
        Me.Controls.Add(Me.pic7)
        Me.Controls.Add(Me.pic6)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnDeal)
        Me.Controls.Add(Me.pic5)
        Me.Controls.Add(Me.pic4)
        Me.Controls.Add(Me.pic3)
        Me.Controls.Add(Me.pic2)
        Me.Controls.Add(Me.pic1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pic1 As PictureBox
    Friend WithEvents pic2 As PictureBox
    Friend WithEvents pic3 As PictureBox
    Friend WithEvents pic4 As PictureBox
    Friend WithEvents pic5 As PictureBox
    Friend WithEvents btnDeal As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents pic6 As PictureBox
    Friend WithEvents pic7 As PictureBox
    Friend WithEvents pic8 As PictureBox
    Friend WithEvents pic9 As PictureBox
    Friend WithEvents pic10 As PictureBox
    Friend WithEvents imlDeck As ImageList
    Friend WithEvents btnReset As Button
End Class
