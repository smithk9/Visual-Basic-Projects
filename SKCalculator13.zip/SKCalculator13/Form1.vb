﻿Public Class Form1
    'Smith Kemper
    'Mckeown
    'Program 13 
    Friend WithEvents btnExit As New System.Windows.Forms.Button
    Friend WithEvents btnZero As New System.Windows.Forms.Button
    Friend WithEvents btnOne As New System.Windows.Forms.Button
    Friend WithEvents btnTwo As New System.Windows.Forms.Button
    Friend WithEvents btnThree As New System.Windows.Forms.Button
    Friend WithEvents btnFour As New System.Windows.Forms.Button
    Friend WithEvents btnFive As New System.Windows.Forms.Button
    Friend WithEvents btnSix As New System.Windows.Forms.Button
    Friend WithEvents btnSeven As New System.Windows.Forms.Button
    Friend WithEvents btnEight As New System.Windows.Forms.Button
    Friend WithEvents btnNine As New System.Windows.Forms.Button
    Friend WithEvents btnAdd As New System.Windows.Forms.Button
    Friend WithEvents btnMinus As New System.Windows.Forms.Button
    Friend WithEvents btnMultiply As New System.Windows.Forms.Button
    Friend WithEvents btnDivide As New System.Windows.Forms.Button
    Friend WithEvents btnEqual As New System.Windows.Forms.Button
    Friend WithEvents btnClear As New System.Windows.Forms.Button
    Dim txtNumbers As New TextBox
    Dim value As String = ""
    Dim answer As Double = 0.0
    Dim num1 As Short
    Dim num2 As Short
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        With btnExit
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(240, 295)
            .Text = "E&xit"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With

        With btnZero
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(160, 295)
            .Text = "0"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnOne
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(80, 295)
            .Text = "1"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnTwo
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(0, 295)
            .Text = "2"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnThree
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(0, 245)
            .Text = "3"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnFour
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(80, 245)
            .Text = "4"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnFive
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(160, 245)
            .Text = "5"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnSix
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(0, 195)
            .Text = "6"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnSeven
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(80, 195)
            .Text = "7"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnEight
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(160, 195)
            .Text = "8"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnNine
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(0, 145)
            .Text = "9"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnAdd
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(240, 245)
            .Text = "+"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnMinus
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(240, 195)
            .Text = "-"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnMultiply
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(240, 145)
            .Text = "x"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnDivide
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(240, 95)
            .Text = "/"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With
        With btnEqual
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(240, 45)
            .Text = "="
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With


        With txtNumbers
            .Visible = True
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12, FontStyle.Bold)
            .ForeColor = Color.Black
            .Top = 15
            .Left = 0
            .Width = 150
            .Text = ""
        End With

        With btnClear
            .Visible = True
            .AutoSize = False
            .Width = 75
            .Height = 30
            .Location = New System.Drawing.Point(240, 10)
            .Text = "Clear"
            .Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
            .TabIndex = 2
        End With



        Me.Controls.Add(btnExit)
        Me.Controls.Add(btnZero)
        Me.Controls.Add(btnOne)
        Me.Controls.Add(btnTwo)
        Me.Controls.Add(btnThree)
        Me.Controls.Add(btnFour)
        Me.Controls.Add(btnFive)
        Me.Controls.Add(btnSix)
        Me.Controls.Add(btnSeven)
        Me.Controls.Add(btnEight)
        Me.Controls.Add(btnNine)
        Me.Controls.Add(btnAdd)
        Me.Controls.Add(btnMinus)
        Me.Controls.Add(btnMultiply)
        Me.Controls.Add(btnDivide)
        Me.Controls.Add(btnEqual)
        Me.Controls.Add(btnClear)
        Controls.Add(txtNumbers)

    End Sub

    Private Sub btnExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
    Private Sub btnZero_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnZero.Click, btnOne.Click, btnTwo.Click, btnThree.Click, btnFour.Click, btnFive.Click, btnSix.Click, btnSeven.Click, btnEight.Click, btnNine.Click
        If txtNumbers.Text = value.ToString Then
            txtNumbers.Text = sender.text
        ElseIf txtNumbers.Text = "0" Then
            txtNumbers.Text = sender.text
        Else
            txtNumbers.Text = txtNumbers.Text & sender.text
        End If

    End Sub
    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        value = btnAdd.Text
        num1 = txtNumbers.Text
        txtNumbers.Clear()

    End Sub
    Private Sub btnEqual_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEqual.Click
        num2 = txtNumbers.Text
        If value = "+" Then
            answer = num1 + num2
        End If
        If value = "-" Then
            answer = num1 - num2
        End If
        If value = "x" Then
            answer = num1 * num2
        End If
        If value = "/" Then
            answer = num1 / num2
        End If

        txtNumbers.Text = answer.ToString
    End Sub
    Private Sub btnMinus_CLick(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnMinus.Click
        value = btnMinus.Text
        num1 = txtNumbers.Text
        txtNumbers.Clear()
    End Sub
    Private Sub btnMultiply_CLick(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnMultiply.Click
        value = btnMultiply.Text
        num1 = txtNumbers.Text
        txtNumbers.Clear()
    End Sub
    Private Sub btnDivide_CLick(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDivide.Click
        value = btnDivide.Text
        num1 = txtNumbers.Text
        txtNumbers.Clear()
    End Sub
    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtNumbers.Clear()
    End Sub
End Class
