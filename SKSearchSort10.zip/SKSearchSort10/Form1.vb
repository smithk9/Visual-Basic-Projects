﻿Public Class Form1
    'Smith Kemper
    'McKeown
    'Binary Search Program 10


    Private Sub btnSort_Click(sender As Object, e As EventArgs) Handles btnSort.Click
        Dim strLetters(4999) As String
        Dim strTemp As String
        Dim intMin As Integer
        Dim i As Integer
        Dim j As Integer
        Dim intMid As Integer
        Dim intHIgh As Integer = strLetters.GetUpperBound(0)
        Dim intLow As Integer
        Dim blnDone As Boolean = False
        Dim strSearch As String
        Dim strDetail As String = "Not Found"
        Dim strRandom As String

        'Generate Random Letters
        For i = 0 To 4999
            strRandom = Nothing
            For j = 0 To 5
                strRandom = strRandom & Chr(Int(Rnd() * 26 + 65))

            Next j
            rtbOut.AppendText(strRandom & vbNewLine)
            strLetters(i) = strRandom
        Next i



        'Selection Sort 
        'Sorts Letters in Alphabetical order 
        For i = 0 To strLetters.GetUpperBound(0) - 1
            intMin = i
            For j = i + 1 To strLetters.GetUpperBound(0)
                If strLetters(intMin) > strLetters(j) Then
                    intMin = j
                End If
            Next
            strTemp = strLetters(i)
            strLetters(i) = strLetters(intMin)
            strLetters(intMin) = strTemp
        Next
        rtbOut.Clear()

        For i = 0 To 4999
            rtbOut.AppendText(strLetters(i) & vbNewLine)
        Next


        'input
        strSearch = txtLetters.Text
        strSearch = strSearch.ToUpper
        rtbOut.Clear()



        'Bineary Search
        Do While intLow <= intHIgh And Not blnDone
            intMid = (intLow + intHIgh) \ 2
            If strSearch = strLetters(intMid).ToUpper Then
                strDetail = strLetters(intMid)
                blnDone = True
            Else
                If strSearch < strLetters(intMid).ToUpper Then
                    intHIgh = intMid - 1
                Else
                    intLow = intMid + 1
                End If
            End If

        Loop

        'Output
        rtbOut.AppendText(strDetail & vbNewLine)


    End Sub
End Class
