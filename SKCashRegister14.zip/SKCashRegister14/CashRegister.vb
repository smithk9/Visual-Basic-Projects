﻿Public Class CashRegister
    'Declarations
    Private mPrice As Decimal
    Private mSalesTax As Decimal
    Private mAmountTenedered As Decimal
    Private mTotal As Decimal
    Private mChange As Decimal
    Const MSNGSALESTAXRATE As Single = 0.05

    Public WriteOnly Property AmountTendered() As Decimal
        Set(ByVal value As Decimal)
            mAmountTenedered = value
        End Set
    End Property
    Public WriteOnly Property Price() As Decimal
        Set(ByVal value As Decimal)
            mPrice = value
        End Set
    End Property
    Public ReadOnly Property Total() As Decimal
        Get
            Total = mTotal
        End Get
    End Property
    Public ReadOnly Property Change() As Decimal
        Get
            Change = mChange
        End Get
    End Property
    Public ReadOnly Property Tax() As Decimal
        Get
            Tax = mSalesTax
        End Get
    End Property
    Public Sub CalcTotal(ByVal AmountTendered As Decimal, ByVal Price As Decimal)
        mAmountTenedered = AmountTendered
        mPrice = Price
        mSalesTax = Price * MSNGSALESTAXRATE
        mTotal = Price + Tax
        mChange = AmountTendered - Price - Tax
    End Sub
End Class
