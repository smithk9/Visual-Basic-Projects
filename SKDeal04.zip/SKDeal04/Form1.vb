﻿Public Class Form1
    'Smith Kemper
    'McKeown
    'Program 4
    'shuffle a deck of cards and deal two sets of 5 cards


    Private Sub btnDeal_Click(sender As Object, e As EventArgs) Handles btnDeal.Click
        'Declarations
        Dim sholist(51) As Short
        Dim i As Integer
        Dim sngRandom(51) As Single

        'Processing
        For i = 0 To 51
            sholist(i) = i
            sngRandom(i) = Rnd()
        Next i

        'Sorts the cards/shuffles 
        Array.Sort(sngRandom, sholist)

        'Loads the cards into images 
        pic1.Image = imlDeck.Images.Item(sholist(0))
        pic2.Image = imlDeck.Images.Item(sholist(1))
        pic3.Image = imlDeck.Images.Item(sholist(2))
        pic4.Image = imlDeck.Images.Item(sholist(3))
        pic5.Image = imlDeck.Images.Item(sholist(4))
        pic6.Image = imlDeck.Images.Item(sholist(5))
        pic7.Image = imlDeck.Images.Item(sholist(6))
        pic8.Image = imlDeck.Images.Item(sholist(7))
        pic9.Image = imlDeck.Images.Item(sholist(8))
        pic10.Image = imlDeck.Images.Item(sholist(9))

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'Clears images
        pic1.Image = Nothing
        pic2.Image = Nothing
        pic3.Image = Nothing
        pic4.Image = Nothing
        pic5.Image = Nothing
        pic6.Image = Nothing
        pic7.Image = Nothing
        pic8.Image = Nothing
        pic9.Image = Nothing
        pic10.Image = Nothing
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub
End Class
