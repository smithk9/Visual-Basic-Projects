﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtLetters = New System.Windows.Forms.TextBox()
        Me.btnSort = New System.Windows.Forms.Button()
        Me.rtbOut = New System.Windows.Forms.RichTextBox()
        Me.SuspendLayout()
        '
        'txtLetters
        '
        Me.txtLetters.Location = New System.Drawing.Point(22, 237)
        Me.txtLetters.Name = "txtLetters"
        Me.txtLetters.Size = New System.Drawing.Size(120, 20)
        Me.txtLetters.TabIndex = 0
        '
        'btnSort
        '
        Me.btnSort.Location = New System.Drawing.Point(22, 303)
        Me.btnSort.Name = "btnSort"
        Me.btnSort.Size = New System.Drawing.Size(79, 23)
        Me.btnSort.TabIndex = 1
        Me.btnSort.Text = "Sort"
        Me.btnSort.UseVisualStyleBackColor = True
        '
        'rtbOut
        '
        Me.rtbOut.Dock = System.Windows.Forms.DockStyle.Top
        Me.rtbOut.Location = New System.Drawing.Point(0, 0)
        Me.rtbOut.Name = "rtbOut"
        Me.rtbOut.Size = New System.Drawing.Size(497, 186)
        Me.rtbOut.TabIndex = 2
        Me.rtbOut.Text = ""
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(497, 362)
        Me.Controls.Add(Me.rtbOut)
        Me.Controls.Add(Me.btnSort)
        Me.Controls.Add(Me.txtLetters)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtLetters As TextBox
    Friend WithEvents btnSort As Button
    Friend WithEvents rtbOut As RichTextBox
End Class
