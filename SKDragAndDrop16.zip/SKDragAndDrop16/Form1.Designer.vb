﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.txtNum1 = New System.Windows.Forms.TextBox()
        Me.txtNum2 = New System.Windows.Forms.TextBox()
        Me.lblAnswer = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblOne = New System.Windows.Forms.Label()
        Me.lblTwo = New System.Windows.Forms.Label()
        Me.lblThree = New System.Windows.Forms.Label()
        Me.lblFour = New System.Windows.Forms.Label()
        Me.lblFive = New System.Windows.Forms.Label()
        Me.lblSix = New System.Windows.Forms.Label()
        Me.lblSeven = New System.Windows.Forms.Label()
        Me.lblEight = New System.Windows.Forms.Label()
        Me.lblNine = New System.Windows.Forms.Label()
        Me.lblCorrect = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(264, 235)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(74, 31)
        Me.btnStart.TabIndex = 0
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'txtNum1
        '
        Me.txtNum1.Location = New System.Drawing.Point(24, 36)
        Me.txtNum1.Name = "txtNum1"
        Me.txtNum1.Size = New System.Drawing.Size(78, 20)
        Me.txtNum1.TabIndex = 1
        '
        'txtNum2
        '
        Me.txtNum2.Location = New System.Drawing.Point(24, 82)
        Me.txtNum2.Name = "txtNum2"
        Me.txtNum2.Size = New System.Drawing.Size(78, 20)
        Me.txtNum2.TabIndex = 2
        '
        'lblAnswer
        '
        Me.lblAnswer.AllowDrop = True
        Me.lblAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAnswer.Location = New System.Drawing.Point(23, 132)
        Me.lblAnswer.Name = "lblAnswer"
        Me.lblAnswer.Size = New System.Drawing.Size(78, 22)
        Me.lblAnswer.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(121, 141)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Answer"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(50, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Add"
        '
        'lblOne
        '
        Me.lblOne.AllowDrop = True
        Me.lblOne.AutoSize = True
        Me.lblOne.Location = New System.Drawing.Point(144, 19)
        Me.lblOne.Name = "lblOne"
        Me.lblOne.Size = New System.Drawing.Size(13, 13)
        Me.lblOne.TabIndex = 6
        Me.lblOne.Text = "1"
        '
        'lblTwo
        '
        Me.lblTwo.AllowDrop = True
        Me.lblTwo.AutoSize = True
        Me.lblTwo.Location = New System.Drawing.Point(178, 19)
        Me.lblTwo.Name = "lblTwo"
        Me.lblTwo.Size = New System.Drawing.Size(13, 13)
        Me.lblTwo.TabIndex = 7
        Me.lblTwo.Text = "2"
        '
        'lblThree
        '
        Me.lblThree.AutoSize = True
        Me.lblThree.Location = New System.Drawing.Point(216, 19)
        Me.lblThree.Name = "lblThree"
        Me.lblThree.Size = New System.Drawing.Size(13, 13)
        Me.lblThree.TabIndex = 8
        Me.lblThree.Text = "3"
        '
        'lblFour
        '
        Me.lblFour.AutoSize = True
        Me.lblFour.Location = New System.Drawing.Point(251, 19)
        Me.lblFour.Name = "lblFour"
        Me.lblFour.Size = New System.Drawing.Size(13, 13)
        Me.lblFour.TabIndex = 9
        Me.lblFour.Text = "4"
        '
        'lblFive
        '
        Me.lblFive.AutoSize = True
        Me.lblFive.Location = New System.Drawing.Point(288, 19)
        Me.lblFive.Name = "lblFive"
        Me.lblFive.Size = New System.Drawing.Size(13, 13)
        Me.lblFive.TabIndex = 10
        Me.lblFive.Text = "5"
        '
        'lblSix
        '
        Me.lblSix.AutoSize = True
        Me.lblSix.Location = New System.Drawing.Point(144, 66)
        Me.lblSix.Name = "lblSix"
        Me.lblSix.Size = New System.Drawing.Size(13, 13)
        Me.lblSix.TabIndex = 11
        Me.lblSix.Text = "6"
        '
        'lblSeven
        '
        Me.lblSeven.AutoSize = True
        Me.lblSeven.Location = New System.Drawing.Point(178, 66)
        Me.lblSeven.Name = "lblSeven"
        Me.lblSeven.Size = New System.Drawing.Size(13, 13)
        Me.lblSeven.TabIndex = 12
        Me.lblSeven.Text = "7"
        '
        'lblEight
        '
        Me.lblEight.AutoSize = True
        Me.lblEight.Location = New System.Drawing.Point(216, 66)
        Me.lblEight.Name = "lblEight"
        Me.lblEight.Size = New System.Drawing.Size(13, 13)
        Me.lblEight.TabIndex = 13
        Me.lblEight.Text = "8"
        '
        'lblNine
        '
        Me.lblNine.AutoSize = True
        Me.lblNine.Location = New System.Drawing.Point(251, 66)
        Me.lblNine.Name = "lblNine"
        Me.lblNine.Size = New System.Drawing.Size(13, 13)
        Me.lblNine.TabIndex = 14
        Me.lblNine.Text = "9"
        '
        'lblCorrect
        '
        Me.lblCorrect.AutoSize = True
        Me.lblCorrect.Location = New System.Drawing.Point(50, 166)
        Me.lblCorrect.Name = "lblCorrect"
        Me.lblCorrect.Size = New System.Drawing.Size(0, 13)
        Me.lblCorrect.TabIndex = 15
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(264, 272)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(74, 28)
        Me.btnExit.TabIndex = 16
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(149, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(152, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Drag and Drop Correct Answer"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(350, 327)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblCorrect)
        Me.Controls.Add(Me.lblNine)
        Me.Controls.Add(Me.lblEight)
        Me.Controls.Add(Me.lblSeven)
        Me.Controls.Add(Me.lblSix)
        Me.Controls.Add(Me.lblFive)
        Me.Controls.Add(Me.lblFour)
        Me.Controls.Add(Me.lblThree)
        Me.Controls.Add(Me.lblTwo)
        Me.Controls.Add(Me.lblOne)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblAnswer)
        Me.Controls.Add(Me.txtNum2)
        Me.Controls.Add(Me.txtNum1)
        Me.Controls.Add(Me.btnStart)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnStart As Button
    Friend WithEvents txtNum1 As TextBox
    Friend WithEvents txtNum2 As TextBox
    Friend WithEvents lblAnswer As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblOne As Label
    Friend WithEvents lblTwo As Label
    Friend WithEvents lblThree As Label
    Friend WithEvents lblFour As Label
    Friend WithEvents lblFive As Label
    Friend WithEvents lblSix As Label
    Friend WithEvents lblSeven As Label
    Friend WithEvents lblEight As Label
    Friend WithEvents lblNine As Label
    Friend WithEvents lblCorrect As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents Label3 As Label
End Class
