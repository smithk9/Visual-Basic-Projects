﻿Public Class Form1
    'Smith Kemper
    'McKeown
    'Program14

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtAmount.Clear()
        txtPrice.Clear()
        lblChange.Text = ""
        lblSalesTax.Text = ""
        lblTotal.Text = ""

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim mCalcpurchase As New CashRegister
        Dim decAmount As Decimal
        Dim decPrice As Decimal

        'Input
        decAmount = txtAmount.Text
        decPrice = txtPrice.Text

        'Processing 
        Call mCalcpurchase.CalcTotal(decAmount, decPrice)

        'Output 

        lblSalesTax.Text = mCalcpurchase.Tax.ToString("c")
        lblTotal.Text = mCalcpurchase.Total.ToString("c")
        lblChange.Text = mCalcpurchase.Change.ToString("c")

    End Sub
End Class
